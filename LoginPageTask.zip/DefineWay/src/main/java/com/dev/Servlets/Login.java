package com.dev.Servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String useremail=request.getParameter("username");
		String userpswd=request.getParameter("password");
		
		HttpSession session=request.getSession();
		RequestDispatcher reqdispatch=null;
		
		Connection conn=null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/datastore","root","1234");
			PreparedStatement pst=conn.prepareStatement("select * from users where uemail=? and upswd=? ");
			pst.setString(1, useremail);
			pst.setString(2, userpswd);
			ResultSet rs=pst.executeQuery();
			if(rs.next())//rs has data ie you got data in db
			{
				session.setAttribute("name",rs.getString("uname"));
				//reqdispatch=request.getRequestDispatcher("index.jsp");
				response.sendRedirect("dashboard.jsp");	
				
				
				}
			else
			{
				request.setAttribute("status","failed");
				reqdispatch=request.getRequestDispatcher("login.jsp");
				//response.sendRedirect("login.jsp");
								
			}
			reqdispatch.forward(request,response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

		
	}


