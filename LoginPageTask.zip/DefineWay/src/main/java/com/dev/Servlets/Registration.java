package com.dev.Servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		PrintWriter out=response.getWriter();
//		out.print("sucessfully working");
//      request reaching the servlet
		
		String username=request.getParameter("name");
		String useremail=request.getParameter("email");
		String userpswd=request.getParameter("pass");
		String usermob=request.getParameter("contact");
		
		RequestDispatcher reqdispatch=null;
		
		//sending to database
		Connection conn=null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			 conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/datastore","root","1234");
			PreparedStatement pst=conn.prepareStatement("insert into users(uname,upswd,uemail,umob) values(?,?,?,?)");
			pst.setString(1, username);
			pst.setString(2, userpswd);
			pst.setString(3, useremail);
			pst.setString(4, usermob);
			
			int res=pst.executeUpdate();
			//count of rows
			
			reqdispatch=request.getRequestDispatcher("registration.jsp");
			if(res>0)
			{
				request.setAttribute("status","success");
			}
			else
			{
				request.setAttribute("status","failed");
			}
			reqdispatch.forward(request, response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}
		}
		
	}
	}


